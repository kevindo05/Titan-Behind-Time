# GameMaker RPG Tutorial Base Project


Welcome to the GameMaker RPG Tutorial Base Project. This was created with the intention of
giving you a starting point to follow the GameMaker RPG Tutorial series that you can find [here](https://youtu.be/1J5EydrnIPs).


**Start the RPG tutorial here:  https://youtu.be/1J5EydrnIPs**
